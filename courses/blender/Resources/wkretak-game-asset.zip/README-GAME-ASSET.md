# Wkrętak - game asset i porównanie LOD

Dwa warianty tego samego płaskiego wkrętaka, wysokość 0.206 m, skala 1.
LOD0: 472 trójkąty, rowki w geometrii. LOD1: 280 trójkątów, gładki chwyt, rowki w normal mapie. Każdy wariant ma jeden materiał i swój atlas. Projekt wkretak-game-LOD.blend pokazuje domyślnie LOD1; LOD0 można włączyć w Outlinerze. Nie pokazuj ich jednocześnie w tym samym miejscu.

Same nazwy obiektów i pliki GLB/FBX nie konfigurują automatycznego LOD w silniku. Wybierz jeden wariant dla małego obiektu albo skonfiguruj przełączanie po ocenie wielkości na ekranie. Osobne atlasy w tym porównaniu zwiększają koszt map; oszczędność 192 trójkątów nie jest darmowym przyspieszeniem każdego zastosowania.

## Pliki

- game/Wkretak_LOD0.glb, game/Wkretak_LOD1.glb: siatka z tangentami, osadzony przenośny PBR, domyślnie kolor niebieski.
- game/*.fbx: siatka, UV, normalne, tangenty. Tekstury są osobno, powiązane względnie z textures/game.
- wkretak-game-LOD*.blend: mapy 1024 spakowane; warianty do gry bez high poly. Wspólny projekt zawiera oba LOD. Modele źródłowe high poly i master mapy 2048 są osobnymi zasobami lekcji.

## Tekstury

Wszystkie obrazy w tej paczce mają 1024 x 1024. Neutralny BaseColor i Blue są alternatywami na tym samym UV.

| Nazwa | Zastosowanie | Dane/kolor |
| --- | --- | --- |
| BaseColor_1k | neutralny nośnik plastiku + stal, do maskowanego tintowania | sRGB |
| BaseColor_Blue_1k | gotowy niebieski wariant | sRGB |
| Roughness_1k | chropowatość | Non-Color / linear |
| Metallic_1k | 0 plastik, 1 stal | Non-Color / linear |
| Normal_1k | tangent normal +X +Y +Z | normal map / linear |
| Normal_DX_1k | normal z odwróconym G, +X -Y +Z | normal map / linear |
| ORM_1k | R=1 (bez wypalonego AO), G=Roughness, B=Metallic | Non-Color / linear |
| Unity_StandardURP_MS_1k | R=Metallic, A=1-Roughness | Non-Color / linear |

Do zmiany koloru plastiku we własnym shaderze: maska = 1 - Metallic; wynik = mix(BaseColor, BaseColor * KolorTworzywa, maska). Stal nie jest tintowana. Materiał GLB ma kolor Blue już utrwalony; nie zawiera niestandardowego grafu tintowania Blendera.

Unity Standard/URP metallic workflow: użyj MS, +Y Normal oraz właściwego importu normal mapy. Dla HDRP przygotuj jego Mask Map, nie przypisuj mapy MS bez zmiany układu kanałów. Unreal: ORM oraz Normal_DX albo +Y z odwróceniem zielonego kanału, bez podwójnego odwracania. Godot: GLB i normal +Y, albo własny materiał z ORM. Parametry importu i kompresji zależą od wybranego shadera i wersji silnika.

Przy ponownym imporcie nie zmieniaj przypadkowo docelowych normalnych i triangulacji. Jeśli silnik przelicza tangenty, porównaj wynik z referencją. Eksporty sprawdzono przez ponowny import do Blendera; ten etap nie jest deklaracją testu uruchomieniowego w trzech silnikach.

## Pochodzenie

Geometria i materiały przygotowane w Blenderze na potrzeby kursu. Mapy wypalone z własnych materiałów proceduralnych; nie dołączono cudzych fotografii ani tekstur z zewnętrznych bibliotek. Referencyjne obrazy porównań są w lekcjach.
